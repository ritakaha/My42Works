/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_split.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: exam <marvin@42.fr>                        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/10/18 12:19:25 by exam              #+#    #+#             */
/*   Updated: 2019/10/21 09:23:16 by csuehiro         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>

int		ft_strend(char *str, int i);

int		ft_strncmp(char *s1, char *s2, unsigned int n)
{
	unsigned int	i;
	int				value;

	i = 0;
	value = 0;
	while (value == 0 && (s1[i] != '\0' || s2[i] != '\0') && i < n)
	{
		value = s1[i] - s2[i];
		i++;
	}
	return (value);
}

int		count_words(char *str, char *charset)
{
	int	i;
	int	count;
	int	new_word;
	int set_len;

	i = 0;
	count = 0;
	new_word = 0;
	set_len = ft_strend(charset, 0);
	while (str[i] != '\0' && str[i + set_len - 1] != '\0')
	{
		if (ft_strncmp(charset, &str[i], set_len) == 0)
		{
			new_word = 0;
			i = i + set_len - 1;
		}
		else
		{
			if (new_word == 0)
				count++;
			new_word = 1;
		}
		i++;
	}
	return (count);
}

int		ft_strend(char *str, int i)
{
	while (str[i] != 0)
	{
		if (str[i] == ' ' || (str[i] >= 9 && str[i] <= 13)) //alterar essa condição
			return (i);
		i++;
	}
	return (i);
}

char	*ft_putstr(char *str, int begin)
{
	char	*aux;
	int		end;
	int		i;

	i = 0;
	end = ft_strend(str, begin);
	aux = malloc((end - begin + 1) * sizeof(char));
	while ((begin + i) < end)
	{
		aux[i] = str[begin + i];
		i++;
	}
	aux[i] = '\0';
	return (aux);
}

char	**ft_split(char *str, char *charset)
{
	char	**str_split;
	char	*aux;
	int		i;
	int		count;

	count = count_words(str, charset);
	if (count > 0)
	{
		str_split = malloc((count + 1) * sizeof(char *));
		i = 0;
		count = 0;
		while (str[i] != '\0')
		{
			if (!(str[i] == ' ' || (str[i] >= 9 && str[i] <= 13))) //alterar essa condição
			{
				str_split[count] = ft_putstr(str, i);
				i = ft_strend(str, i) - 1;
				count++;
			}
			i++;
		}
	}
	else
		str_split = malloc(sizeof(char *));
	aux = malloc(sizeof(char));
	*aux = 0;
	str_split[count] = aux;
	return (str_split);
}
