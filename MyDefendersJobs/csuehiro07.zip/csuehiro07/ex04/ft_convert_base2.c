/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_conver_base2.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: csuehiro <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/10/21 09:16:17 by csuehiro          #+#    #+#             */
/*   Updated: 2019/10/21 09:17:06 by csuehiro         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	check_isspace(char c);

int	check_issign(char c, int *sign)
{
	if (c == '-' || c == '+')
	{
		if (c == '-')
			*sign = *sign * (-1);
		return (1);
	}
	else
		return (0);
}

int	check_isspace(char c)
{
	if (c == '\t' || c == '\n' || c == '\v')
		return (1);
	if (c == '\f' || c == '\r' || c == ' ')
		return (1);
	return (0);
}
