/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_convert_base.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: csuehiro <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/10/21 09:15:55 by csuehiro          #+#    #+#             */
/*   Updated: 2019/10/21 09:17:40 by csuehiro         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	check_isspace(char c);
int	check_issign(char c, int *sign);

int	ft_atoi(char *str)
{
	int i;
	int nb;
	int step;
	int sign;

	i = 0;
	step = 0;
	sign = 1;
	nb = 0;
	while (str[i] != '\0' && step != 3)
	{
		if (step == 0 && !check_isspace(str[i]))
			step = 1;
		if (step == 1 && !check_issign(str[i], &sign))
			step = 2;
		if (step == 2 && str[i] >= '0' && str[i] <= '9')
			nb = nb * 10 + (str[i] - '0');
		if (step == 2 && (str[i] < '0' || str[i] > '9'))
			step = 3;
		i++;
	}
	nb = nb * sign;
	return (nb);
}
