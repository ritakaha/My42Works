/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_ultimate_range.c                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: csuehiro <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/10/16 19:41:10 by csuehiro          #+#    #+#             */
/*   Updated: 2019/10/17 11:01:11 by csuehiro         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>

int	ft_ultimate_range(int **range, int min, int max)
{
	int		i;
	long	a;

	if (min >= max)
	{
		*range = 0;
		return (0);
	}
	a = (long)max - (long)min;
	if (a > 2147483648)
		return (-1);
	*range = malloc((max - min) * sizeof(int));
	i = 0;
	while (i < max - min)
	{
		range[0][i] = min + i;
		i++;
	}
	return (i);
}
