/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strjoin.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: csuehiro <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/10/17 14:07:12 by csuehiro          #+#    #+#             */
/*   Updated: 2019/10/18 15:31:33 by csuehiro         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>

int		count_sep(char *sep);
int		count_char(int size, char **strs, char *sep);
int		put_sep(char *sep, char *res, int count);
char	*ft_strjoin_aux(int size, char **strs, char *sep);

char	*ft_strjoin(int size, char **strs, char *sep)
{
	char	*res;

	if (size == 0)
	{
		res = malloc(sizeof(char));
		res[0] = 0;
	}
	else
		res = ft_strjoin_aux(size, strs, sep);
	return (res);
}

char	*ft_strjoin_aux(int size, char **strs, char *sep)
{
	char	*res;
	int		i;
	int		j;
	int		count;

	res = malloc(count_char(size, strs, sep) * sizeof(char));
	i = -1;
	count = 0;
	while (++i < size)
	{
		j = 0;
		while (strs[i][j] != '\0')
		{
			res[count] = strs[i][j];
			count++;
			j++;
		}
		if (i != size - 1)
			count = put_sep(sep, res, count);
	}
	return (res);
}

int		put_sep(char *sep, char *res, int count)
{
	int i;

	i = 0;
	while (sep[i] != '\0')
	{
		res[count] = sep[i];
		count++;
		i++;
	}
	return (count);
}

int		count_sep(char *sep)
{
	int i;

	i = 0;
	while (sep[i] != '\0')
	{
		i++;
	}
	return (i);
}

int		count_char(int size, char **strs, char *sep)
{
	int i;
	int j;
	int counter;
	int size_sep;

	i = -1;
	counter = 0;
	size_sep = count_sep(sep);
	while (++i < size)
	{
		j = 0;
		while (strs[i][j] != '\0')
		{
			counter++;
			j++;
		}
		if (i != size - 1)
			counter = counter + size_sep;
	}
	return (counter);
}
