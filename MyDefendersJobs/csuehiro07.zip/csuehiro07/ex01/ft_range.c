/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_range.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: csuehiro <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/10/16 18:41:30 by csuehiro          #+#    #+#             */
/*   Updated: 2019/10/21 09:20:48 by csuehiro         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>

int	*ft_range(int min, int max)
{
	int *matrix;
	int i;

	if (min >= max)
		return (NULL);
	matrix = malloc((max - min) * sizeof(int));
	i = 0;
	while (i < max - min)
	{
		matrix[i] = min + i;
		i++;
	}
	return (matrix);
}
